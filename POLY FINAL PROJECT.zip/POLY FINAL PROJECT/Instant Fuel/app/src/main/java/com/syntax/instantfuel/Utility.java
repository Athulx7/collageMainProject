package com.syntax.instantfuel;

public class Utility {

    public static String ip = "192.168.29.72";

    public static String SERVERUrl = "http://"+ip.trim()+":8080/Fuel_Tracker_Server/serverFS/FuelSpot_Server.jsp";

}
